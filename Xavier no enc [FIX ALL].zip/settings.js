const fs = require('fs')

global.nowner = ""//Owner Number
global.namaowner = ""//Owner Name
global.namabot = ""//Bot Name

//pay
global.dana = ""
global.ovo = ""
global.gopay = ""

global.msg = {
owner: "*[ 403 ]* Owner Only",
premium: "*[ 403 ]* Premium User Only",
group: "*[ 405 ]* Group Only"
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})